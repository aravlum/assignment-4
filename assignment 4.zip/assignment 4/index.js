function validateForm() {
  let x = document.forms["myForm"]["fname"].value;
  if (x == "") {
    alert("Everything must be filled out");
  }
  else{
    alert("shds");
  }
}
document.querySelector("a.navbar-brand").addEventListener("click", handleClick);
function handleClick(){
  alert("You clicked");
}

function play() {
  var audio = new Audio('audio .mp3');
  audio.play();
}


function changeText(id) {
  id.innerHTML = "Choice for every taste!";
}

function mOver(obj) {
  obj.innerHTML = "Without joke!"
}

function mOut(obj) {
  obj.innerHTML = "We recommend only the best "
}

var textWrapper = document.querySelector('.ml7 .letters');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.ml7 .letter',
    translateY: ["1.1em", 0],
    translateX: ["0.55em", 0],
    translateZ: 0,
    rotateZ: [180, 0],
    duration: 750,
    easing: "easeOutExpo",
    delay: (el, i) => 50 * i
  }).add({
    targets: '.ml7',
    opacity: 0,
    duration: 1000,
    easing: "easeOutExpo",
    delay: 1000
  });
